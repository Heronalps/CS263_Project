#config file containing credentials for rds mysql instance
db_username = "michael"
db_password = "qwerty46"
db_name = "myLatencyExperimentDB"
db_endpoint = "latencyexperiment.cxfpxjlukepw.us-west-2.rds.amazonaws.com"
